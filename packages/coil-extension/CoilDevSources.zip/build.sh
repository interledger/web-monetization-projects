../webexts-build-utils/scripts/build.sh "$@"
