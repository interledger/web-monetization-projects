cp icn-coil-ext@4x.png inactive.png
cp icn-coil-ext-alert@4x.png monetized-unavailable.png
cp icn-coil-ext-alert@4x.png inactive-unavailable.png
cp icn-coil-ext-streaming@4x.png monetized-streaming.png
cp icn-coil-ext-connecting@4x.png monetized.png
