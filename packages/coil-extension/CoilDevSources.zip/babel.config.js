// FROM UPKEEP TEMPLATE
// Jest will look for a babel config in the
// same directory as the jest.config.js
module.exports = {
  ...require('../../babel.config')
}
