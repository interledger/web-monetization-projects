export { StorageService } from '@webmonetization/wext/undecorated'
