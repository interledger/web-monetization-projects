export { portableFetch } from '@webmonetization/polyfill-utils'
