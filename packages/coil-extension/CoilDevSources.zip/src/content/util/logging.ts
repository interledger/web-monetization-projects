import { makeLogger } from '../../util/logging'

export const debug = makeLogger('content')
