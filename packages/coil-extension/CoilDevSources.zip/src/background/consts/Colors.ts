export const Colors = {
  White: '#fff',
  Red: '#EC5F59',
  Green: '#40C28D'
}
