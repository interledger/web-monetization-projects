export const TipAssets = {
  assetCode: 'USD',
  assetScale: 2
}
