export type WextApi = typeof window.chrome
