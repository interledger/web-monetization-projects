export interface BuildConfig {
  logTabsApiEvents?: boolean
  extensionBuildString?: string
  extensionPopupFooterString?: string
  isCI?: boolean
  isLoggingEnabled?: boolean
}
