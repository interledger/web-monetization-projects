export enum ROUTES {
  streaming = 'streaming',
  tipping = 'tipping',
  tippingConfirm = 'tipping/confirm',
  tippingComplete = 'tipping/complete',
  settings = 'settings'
}
