import { styled } from '@material-ui/core'

export const Flex = styled('div')({
  flex: 1
})
