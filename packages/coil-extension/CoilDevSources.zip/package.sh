../webexts-build-utils/scripts/package.sh "$1" coilfirefoxextension@coil.com.xpi coil_extension.zip coil_extension_edge.zip
